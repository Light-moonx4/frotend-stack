export interface BandMember {
  name: string;
  role: string;
  imageUrl: string;
}

export interface MusicEventItem{
  id: string;
  title: string;
  category: "music";
  date: string;
  location: string;
  description: string;
  youtubeId: string;
  bandMembers: BandMember[];
}

export const eventsData: MusicEventItem[] | any[] = [
  {
    id: "linkin-park-in-the-end",
    title: "Linkin Park - In The End",
    category: "music",
    date: "2023-09-15",
    location: "Madison Square Garden, New York, NY",
    description: "Join us for an unforgettable night as Linkin Park performs their iconic hit 'In The End' live on stage.",
    youtubeId: "eVTXPUF4Oz4",
    bandMembers: [
      {name: "Chester Bennington", role: "Lead Vocals", imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=300&q=80"},
      {name: "Mike Shinoda", role: "Vocals, Rhythm Guitar, Keyboards", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"},
      {name: "Brad Delson", role: "Lead Guitar", imageUrl: "https://images.unsplash.com/photo-1563381313-5a9db07cc053?auto=format&fit=crop&w=300&q=80"},
      {name: "Dave 'Phoenix' Farrell", role: "Bass Guitar", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"},
      {name: "Rob Bourdon", role: "Drums", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"},
      {name: "Joe Hahn", role: "Turntables, Sampling", imageUrl: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=300&q=80"}
    ]
  },
  {
    id: "skillet-monster",
    title: "Skillet - Monster",
    category: "music",
    date: "2023-10-20",
    location: "Hollywood Bowl, Los Angeles, CA",
    description: "Experience the electrifying performance of Skillet as they bring their hit song 'Monster' to life on stage.",
    youtubeId: "0m6a2c4g1kY",
    bandMembers: [
      {name: "John Cooper", role: "Lead Vocals, Bass Guitar", imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=300&q=80"},
      {name: "Korey Cooper", role: "Rhythm Guitar, Keyboards", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"},
      {name: "Jen Ledger", role: "Drums, Vocals", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"},
      {name: "Seth Morrison", role: "Lead Guitar", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=300&q=80"}
    ]
  },
  {
    id: "evanescence-bring-me-to-life",
    title: "Evanescence - Bring Me To Life",
    category: "music",
    date: "2023-11-15",
    location: "The Forum, Los Angeles, CA",
    description: "Join Evanescence for an unforgettable night as they perform their hit song 'Bring Me To Life' live on stage.",
    youtubeId: "k4V1oDl39B4",
    bandMembers: [
      {name: "Amy Lee", role: "Lead Vocals", imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"},
      {name: "John LeCompt", role: "Guitar, Keyboards", imageUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80"},
      {name: "Ben Moody", role: "Guitar", imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80"},
      {name: "Rocky Gray", role: "Drums", imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80"},
    ]
  },
];