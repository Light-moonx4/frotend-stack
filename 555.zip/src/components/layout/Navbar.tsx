"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import ThemeToggleButton from "../ui/ThemeToggleButton";

export default function Navbar() {
  const [favoriteCount, setFavoriteCount] = useState(0);

  useEffect(() => {
    const updateCount = () => {
      try {
        const saved = localStorage.getItem("shadow_favorites");
        if (saved) {
          const list = JSON.parse(saved);
          setFavoriteCount(list.length);
        } else {
          setFavoriteCount(0);
        }
      } catch {
        setFavoriteCount(0);
      }
    };

    updateCount();
    window.addEventListener("favorites_updated", updateCount);
    return () => window.removeEventListener("favorites_updated", updateCount);
  }, []);

  return (
    <nav className="sticky top-0 z-40 backdrop-blur-md bg-white/80 dark:bg-gray-900/80 border-b border-gray-200 dark:border-gray-800 transition-colors">
      <div className="mx-auto max-w-7xl px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-black text-xl tracking-tight text-gray-900 dark:text-white">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-500/30 text-lg">
            ⚡
          </span>
          <span>Shadow <span className="text-blue-600 dark:text-blue-400 font-semibold">Catálogo</span></span>
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center gap-6">
          <Link
            href="/"
            className="hover:text-blue-500 text-gray-700 dark:text-gray-300 text-sm font-medium transition-colors"
          >
            Inicio
          </Link>
          <Link
            href="/events"
            className="hover:text-blue-500 text-gray-700 dark:text-gray-300 text-sm font-medium transition-colors"
          >
            Eventos
          </Link>
          <Link
            href="/categories"
            className="hover:text-blue-500 text-gray-700 dark:text-gray-300 text-sm font-medium transition-colors"
          >
            Categorías
          </Link>
          <Link
            href="/favorites"
            className="relative hover:text-blue-500 text-gray-700 dark:text-gray-300 text-sm font-medium transition-colors flex items-center gap-1.5"
          >
            <span>Favoritos</span>
            {favoriteCount > 0 && (
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm">
                {favoriteCount}
              </span>
            )}
          </Link>
          <Link
            href="/admin/categories/create"
            className="hidden sm:inline-flex px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 text-xs font-semibold hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          >
            + Admin
          </Link>

          {/* Theme Switcher */}
          <ThemeToggleButton />
        </div>
      </div>
    </nav>
  );
}