import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-auto border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 transition-colors">
      <div className="mx-auto max-w-7xl px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-600 text-white text-xs font-bold">
            ⚡
          </span>
          <span className="font-bold text-gray-900 dark:text-white text-sm">
            Shadow Catálogo
          </span>
          <span className="text-xs text-gray-500">© 2026. Todos los derechos reservados.</span>
        </div>

        <div className="flex items-center gap-6 text-xs text-gray-500 dark:text-gray-400">
          <Link href="/events" className="hover:text-blue-500 transition-colors">
            Eventos
          </Link>
          <Link href="/categories" className="hover:text-blue-500 transition-colors">
            Categorías
          </Link>
          <Link href="/favorites" className="hover:text-blue-500 transition-colors">
            Favoritos
          </Link>
          <Link href="/admin/categories/create" className="hover:text-blue-500 transition-colors">
            Crear Categoría
          </Link>
        </div>
      </div>
    </footer>
  );
}