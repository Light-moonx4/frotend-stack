"use client";

import Link from "next/link";
import { useState } from "react";
import { EventItem } from "@/data/events";
import FavoriteButton from "./FavoriteButton";
import TicketModal from "./TicketModal";

interface EventCardProps {
  event: EventItem;
}

const categoryLabels: Record<string, { label: string; color: string }> = {
  music: { label: "Música", color: "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300" },
  games: { label: "Videojuegos", color: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300" },
  theatre: { label: "Teatro", color: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300" },
  football: { label: "Fútbol", color: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300" },
};

export default function EventCard({ event }: EventCardProps) {
  const [isTicketOpen, setIsTicketOpen] = useState(false);
  const categoryInfo = categoryLabels[event.category] || { label: event.category, color: "bg-gray-100 text-gray-700" };

  return (
    <>
      <div className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
        {/* Event Image & Badges */}
        <div className="relative h-48 w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
          {/* Background Image */}
          <img
            src={event.imageUrl}
            alt={event.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

          {/* Top Bar Badges & Favorite */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md shadow-sm ${categoryInfo.color}`}>
              {categoryInfo.label}
            </span>
            <FavoriteButton eventId={event.id} />
          </div>

          {/* Bottom Left Price Badge */}
          <div className="absolute bottom-3 left-3">
            <span className="px-3 py-1 rounded-lg bg-white/90 dark:bg-gray-900/90 text-xs font-bold text-gray-900 dark:text-white backdrop-blur-md shadow-sm">
              {event.price === 0 ? "Gratis" : `$${event.price} USD`}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-1 flex-col justify-between p-5">
          <div>
            <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
              📅 {event.date}
            </p>
            <h3 className="mt-1 text-lg font-bold text-gray-900 dark:text-white line-clamp-1 group-hover:text-blue-500 transition-colors">
              {event.title}
            </h3>
            <p className="mt-2 text-xs text-gray-600 dark:text-gray-400 line-clamp-2 leading-relaxed">
              {event.description}
            </p>
            <p className="mt-3 text-xs text-gray-500 dark:text-gray-500 flex items-center gap-1">
              📍 {event.location}
            </p>
          </div>

          {/* Actions */}
          <div className="mt-5 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between gap-2">
            <Link
              href={`/events/${event.id}`}
              className="text-xs font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
            >
              Ver Detalle &rarr;
            </Link>
            <button
              onClick={() => setIsTicketOpen(true)}
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-colors"
            >
              Entradas
            </button>
          </div>
        </div>
      </div>

      <TicketModal
        isOpen={isTicketOpen}
        onClose={() => setIsTicketOpen(false)}
        event={event}
      />
    </>
  );
}

