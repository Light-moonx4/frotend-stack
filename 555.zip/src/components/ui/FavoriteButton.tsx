"use client";

import { useState, useEffect } from "react";

interface FavoriteButtonProps {
  eventId: string;
}

export default function FavoriteButton({ eventId }: FavoriteButtonProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("shadow_favorites");
      if (saved) {
        const favorites: string[] = JSON.parse(saved);
        // eslint-disable-next-line react-hooks/set-state-in-effect -- Lectura única de favoritos en localStorage al montar
        setIsFavorite(favorites.includes(eventId));
      }
    } catch {
      // Ignorar errores de sintaxis
    }
  }, [eventId]);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    try {
      const saved = localStorage.getItem("shadow_favorites");
      let favorites: string[] = saved ? JSON.parse(saved) : [];

      if (favorites.includes(eventId)) {
        favorites = favorites.filter((id) => id !== eventId);
        setIsFavorite(false);
      } else {
        favorites.push(eventId);
        setIsFavorite(true);
      }

      localStorage.setItem("shadow_favorites", JSON.stringify(favorites));
      window.dispatchEvent(new Event("favorites_updated"));
    } catch {
      // Error de storage
    }
  };

  return (
    <button
      onClick={toggleFavorite}
      className={`p-2 rounded-full transition-all backdrop-blur-md ${
        isFavorite
          ? "bg-rose-500 text-white shadow-lg shadow-rose-500/30 scale-110"
          : "bg-white/80 dark:bg-gray-900/80 text-gray-400 hover:text-rose-500 hover:bg-white dark:hover:bg-gray-900"
      }`}
      aria-label={isFavorite ? "Quitar de favoritos" : "Guardar en favoritos"}
      title={isFavorite ? "Quitar de favoritos" : "Guardar en favoritos"}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill={isFavorite ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-4 h-4"
      >
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
      </svg>
    </button>
  );
}

