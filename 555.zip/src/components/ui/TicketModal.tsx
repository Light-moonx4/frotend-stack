"use client";

import { useState } from "react";
import Modal from "./Modal";
import { EventItem } from "@/data/events";

interface TicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: EventItem;
}

export default function TicketModal({ isOpen, onClose, event }: TicketModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [purchased, setPurchased] = useState(false);
  const [buyerName, setBuyerName] = useState("");
  const [buyerEmail, setBuyerEmail] = useState("");

  const totalPrice = event.price * quantity;

  const handlePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerName || !buyerEmail) return;
    setPurchased(true);
  };

  const handleResetAndClose = () => {
    setPurchased(false);
    setQuantity(1);
    setBuyerName("");
    setBuyerEmail("");
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleResetAndClose} title={`Entradas - ${event.title}`}>
      {purchased ? (
        <div className="text-center py-4 space-y-4">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 text-3xl">
            ✓
          </div>
          <h4 className="text-2xl font-bold text-gray-900 dark:text-white">
            ¡Reserva Confirmada!
          </h4>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Gracias <span className="font-semibold text-gray-900 dark:text-white">{buyerName}</span>. 
            Hemos enviado tus <span className="font-semibold">{quantity} entrada(s)</span> a{" "}
            <span className="font-semibold text-blue-600 dark:text-blue-400">{buyerEmail}</span>.
          </p>
          <div className="rounded-xl p-4 bg-gray-50 dark:bg-gray-800/50 text-left text-xs space-y-1 text-gray-600 dark:text-gray-300">
            <p><strong>Evento:</strong> {event.title}</p>
            <p><strong>Fecha:</strong> {event.date}</p>
            <p><strong>Lugar:</strong> {event.location}</p>
            <p><strong>Total abonado:</strong> ${totalPrice} USD</p>
          </div>
          <button
            onClick={handleResetAndClose}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-colors text-sm"
          >
            Entendido
          </button>
        </div>
      ) : (
        <form onSubmit={handlePurchase} className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-800">
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Precio por entrada</p>
              <p className="text-lg font-bold text-gray-900 dark:text-white">
                {event.price === 0 ? "¡Gratis!" : `$${event.price} USD`}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500 dark:text-gray-400">Entradas disponibles</p>
              <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                {event.availableTickets} tickets
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              Cantidad de tickets
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 rounded-lg border border-gray-200 dark:border-gray-800 flex items-center justify-center font-bold text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                -
              </button>
              <span className="text-lg font-bold text-gray-900 dark:text-white w-8 text-center">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                className="w-10 h-10 rounded-lg border border-gray-200 dark:border-gray-800 flex items-center justify-center font-bold text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                +
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              Nombre Completo
            </label>
            <input
              type="text"
              required
              placeholder="Ej: Carlos Pérez"
              value={buyerName}
              onChange={(e) => setBuyerName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              Correo Electrónico
            </label>
            <input
              type="email"
              required
              placeholder="ejemplo@correo.com"
              value={buyerEmail}
              onChange={(e) => setBuyerEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Total a pagar</p>
              <p className="text-xl font-bold text-blue-600 dark:text-blue-400">
                {totalPrice === 0 ? "Gratis" : `$${totalPrice} USD`}
              </p>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-colors text-sm shadow-md shadow-blue-500/20"
            >
              Confirmar Reserva
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}

