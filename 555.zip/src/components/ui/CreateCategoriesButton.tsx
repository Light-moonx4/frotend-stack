import Link from "next/link";

export default function CreateCategoriesButton() {
  return (
    <Link
      href="/admin/categories/create"
      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 transition-all"
    >
      <span>+</span>
      <span>Crear Categoría</span>
    </Link>
  );
}