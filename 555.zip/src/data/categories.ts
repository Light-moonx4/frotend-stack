export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  image: string;
  color: string;
}

export const categoriesData: CategoryItem[] = [
  {
    id: "all",
    name: "Todos los Eventos",
    slug: "all",
    description: "Explora la lista completa de eventos disponibles en el catálogo.",
    icon: "📅",
    image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80",
    color: "from-blue-600 to-indigo-600",
  },
  {
    id: "music",
    name: "Música",
    slug: "music",
    description: "Conciertos, festivales en vivo y presentaciones musicales memorables.",
    icon: "🎵",
    image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80",
    color: "from-purple-600 to-pink-600",
  },
  {
    id: "games",
    name: "Videojuegos",
    slug: "games",
    description: "Convenciones gamer, lanzamientos y torneos de esports.",
    icon: "🎮",
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80",
    color: "from-green-600 to-emerald-600",
  },
  {
    id: "theatre",
    name: "Teatro",
    slug: "theatre",
    description: "Obras dramáticas, musicales y muestras escénicas regionales.",
    icon: "🎭",
    image: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?auto=format&fit=crop&w=800&q=80",
    color: "from-amber-600 to-orange-600",
  },
  {
    id: "football",
    name: "Fútbol",
    slug: "football",
    description: "Partidos de liga, campeonatos internacionales y finales emocionantes.",
    icon: "⚽",
    image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=800&q=80",
    color: "from-red-600 to-rose-600",
  },
];