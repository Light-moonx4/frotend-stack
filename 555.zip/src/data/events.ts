export interface EventItem {
  id: string;
  title: string;
  category: "music" | "games" | "theatre" | "football";
  date: string;
  location: string;
  description: string;
  price: number;
  capacity: number;
  availableTickets: number;
  imageUrl: string;
  featured?: boolean;
  organizer: string;
}

export const eventsData: EventItem[] = [
  // --- VIDEOJUEGOS (Games) ---
  {
    id: "tokyo-game-show-2026",
    title: "Tokyo Game Show 2026",
    category: "games",
    date: "16 al 20 de Septiembre, 2026",
    location: "Makuhari Messe, Chiba, Japón",
    description: "Una de las ferias de videojuegos más grandes e influyentes del mundo con presentaciones exclusivas, demos jugables y anuncios desde Japón.",
    price: 45,
    capacity: 250000,
    availableTickets: 1200,
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80",
    featured: true,
    organizer: "Computer Entertainment Supplier's Association (CESA)",
  },
  {
    id: "blizzcon-2026",
    title: "BlizzCon 2026",
    category: "games",
    date: "12 de Septiembre, 2026",
    location: "Anaheim Convention Center, California, EE.UU.",
    description: "La convención anual épica enfocada en las franquicias de Blizzard Entertainment: Warcraft, Overwatch, Diablo y StarCraft.",
    price: 120,
    capacity: 35000,
    availableTickets: 450,
    imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80",
    featured: true,
    organizer: "Blizzard Entertainment",
  },
  {
    id: "level-5-vision-2026",
    title: "LEVEL-5 Vision 2026 II",
    category: "games",
    date: "10 de Septiembre, 2026",
    location: "Japón (Streaming Online)",
    description: "Presentación especial de LEVEL-5 con primicias de Inazuma Eleven, Professor Layton y nuevos títulos RPG.",
    price: 0,
    capacity: 100000,
    availableTickets: 5000,
    imageUrl: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80",
    featured: false,
    organizer: "LEVEL-5 Inc.",
  },

  // --- MÚSICA (Music) ---
  {
    id: "skillet-louder-than-life",
    title: "Skillet en Louder Than Life 2026",
    category: "music",
    date: "17 de Septiembre, 2026",
    location: "Highland Festival Grounds, Louisville, KY, EE.UU.",
    description: "Presentación en vivo con toda la energía rockera de Skillet en el festival Louder Than Life.",
    price: 85,
    capacity: 60000,
    availableTickets: 890,
    imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80",
    featured: true,
    organizer: "Danny Wimmer Presents",
  },
  {
    id: "linkin-park-wabash",
    title: "Linkin Park en Concierto",
    category: "music",
    date: "18 de Septiembre, 2026",
    location: "Honeywell Center, Wabash, IN, EE.UU.",
    description: "Concierto único de Linkin Park en su nueva etapa, interpretando clásicos y temas de su álbum más reciente.",
    price: 110,
    capacity: 15000,
    availableTickets: 230,
    imageUrl: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=800&q=80",
    featured: true,
    organizer: "Live Nation Entertainment",
  },
  {
    id: "linkin-park-zurich",
    title: "Linkin Park - Estadio Letzigrund",
    category: "music",
    date: "30 de Junio, 2026",
    location: "Estadio Letzigrund, Zúrich, Suiza",
    description: "Espectáculo masivo de nivel de estadio en Europa con una producción audiovisual sorprendente.",
    price: 130,
    capacity: 48000,
    availableTickets: 120,
    imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80",
    featured: false,
    organizer: "Good News Productions",
  },

  // --- TEATRO (Theatre) ---
  {
    id: "jury-experience",
    title: "The Jury Experience: El Robo de los 20 Millones",
    category: "theatre",
    date: "25 de Septiembre, 2026",
    location: "Teatro Principal, Sala A",
    description: "Una experiencia dramática inmersiva en la que el público actúa como jurado popular en un juicio de alta tensión.",
    price: 35,
    capacity: 400,
    availableTickets: 65,
    imageUrl: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?auto=format&fit=crop&w=800&q=80",
    featured: false,
    organizer: "Compañía de Teatro Inmersivo",
  },
  {
    id: "sabanalarga-vive-teatro",
    title: "Encuentro Regional 'Sabanalarga Vive Teatro'",
    category: "theatre",
    date: "19 de Septiembre, 2026",
    location: "Plaza de la Cultura, Sabanalarga, Atlántico",
    description: "Festival cultural itinerante con más de 12 agrupaciones teatrales locales y regionales en escena.",
    price: 15,
    capacity: 1200,
    availableTickets: 400,
    imageUrl: "https://images.unsplash.com/photo-1460723237483-7a6dc9d0b212?auto=format&fit=crop&w=800&q=80",
    featured: false,
    organizer: "Alcaldía de Sabanalarga & Casa de la Cultura",
  },

  // --- FÚTBOL (Football) ---
  {
    id: "champions-league-final",
    title: "Final de la UEFA Champions League 2026",
    category: "football",
    date: "30 de Mayo, 2026",
    location: "Puskás Aréna, Budapest, Hungría",
    description: "El evento cumbre del fútbol de clubes europeo. Los dos mejores equipos del continente chocan por el título sagrado.",
    price: 250,
    capacity: 67000,
    availableTickets: 95,
    imageUrl: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=800&q=80",
    featured: true,
    organizer: "UEFA",
  },
  {
    id: "liga-betplay-final",
    title: "Gran Final Liga BetPlay 2026",
    category: "football",
    date: "21 de Junio, 2026",
    location: "Estadio El Campín, Bogotá, Colombia",
    description: "El partido definitivo que consagrará al campeón del primer semestre en la máxima categoría del fútbol colombiano.",
    price: 60,
    capacity: 36000,
    availableTickets: 310,
    imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=800&q=80",
    featured: false,
    organizer: "DIMAYOR",
  },
];