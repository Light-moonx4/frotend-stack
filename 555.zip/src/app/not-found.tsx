import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-20 text-center space-y-6">
      <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-3xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 text-5xl">
        ⚡
      </div>
      <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white">
        404 - Página no encontrada
      </h1>
      <p className="text-gray-600 dark:text-gray-300 max-w-md mx-auto text-sm leading-relaxed">
        El evento, categoría o recurso al que estás intentando acceder no existe o ha sido movido.
      </p>
      <div className="flex justify-center gap-4 pt-4">
        <Link
          href="/"
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 transition-colors"
        >
          Volver al Inicio
        </Link>
        <Link
          href="/events"
          className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-800 text-xs font-semibold text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        >
          Ver Eventos
        </Link>
      </div>
    </div>
  );
}

