"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { eventsData, EventItem } from "@/data/events";
import EventCard from "@/components/ui/EventCard";

export default function FavoritesPage() {
  const [favoriteEvents, setFavoriteEvents] = useState<EventItem[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  const loadFavorites = useCallback(() => {
    try {
      const saved = localStorage.getItem("shadow_favorites");
      if (saved) {
        const favoriteIds: string[] = JSON.parse(saved);
        const filtered = eventsData.filter((e) => favoriteIds.includes(e.id));
        setFavoriteEvents(filtered);
      } else {
        setFavoriteEvents([]);
      }
    } catch {
      setFavoriteEvents([]);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- Carga inicial de favoritos al montar el componente
    loadFavorites();
    window.addEventListener("favorites_updated", loadFavorites);
    return () => window.removeEventListener("favorites_updated", loadFavorites);
  }, [loadFavorites]);

  return (
    <div className="mx-auto max-w-7xl p-6 space-y-8">
      <div className="border-b border-gray-200 dark:border-gray-800 pb-6">
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white flex items-center gap-3">
          <span>💖</span> Mis Eventos Favoritos
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Eventos guardados para no perderte ninguna actualización o entrada.
        </p>
      </div>

      {!isLoaded ? (
        <div className="p-12 text-center text-gray-500">Cargando tus favoritos...</div>
      ) : favoriteEvents.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-4 max-w-lg mx-auto">
          <span className="text-5xl">🤍</span>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">
            No tienes eventos guardados aún
          </h3>
          <p className="text-xs text-gray-500">
            Explora el catálogo y presiona el ícono del corazón en cualquier tarjeta para guardarlo en tus favoritos.
          </p>
          <div className="pt-2">
            <Link
              href="/events"
              className="inline-block px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs shadow-md hover:bg-blue-500 transition-colors"
            >
              Explorar Eventos &rarr;
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favoriteEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
}

