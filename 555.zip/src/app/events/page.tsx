"use client";

import { useSearchParams } from "next/navigation";
import { useState, useMemo, Suspense } from "react";
import EventsAside from "@/components/events/EventsAside";
import EventCard from "@/components/ui/EventCard";
import SearchBar from "@/components/ui/SearchBar";
import { eventsData } from "@/data/events";

function EventsContent() {
  const searchParams = useSearchParams();
  const initialCategory = searchParams.get("category") || "all";

  const [categoryFilter, setCategoryFilter] = useState(initialCategory);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("default");

  // Sync category if URL parameter changes
  const activeCategory = searchParams.get("category") || categoryFilter;

  const filteredEvents = useMemo(() => {
    return eventsData
      .filter((event) => {
        // Category filter
        if (activeCategory !== "all" && event.category !== activeCategory) {
          return false;
        }
        // Search term filter
        if (searchTerm.trim() !== "") {
          const query = searchTerm.toLowerCase();
          const matchTitle = event.title.toLowerCase().includes(query);
          const matchDesc = event.description.toLowerCase().includes(query);
          const matchLoc = event.location.toLowerCase().includes(query);
          if (!matchTitle && !matchDesc && !matchLoc) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === "price-asc") return a.price - b.price;
        if (sortBy === "price-desc") return b.price - a.price;
        if (sortBy === "title-asc") return a.title.localeCompare(b.title);
        return 0;
      });
  }, [activeCategory, searchTerm, sortBy]);

  return (
    <div className="mx-auto max-w-7xl p-6 flex flex-col md:flex-row gap-8">
      {/* Sidebar Filters */}
      <EventsAside activeCategory={activeCategory} />

      {/* Main Content */}
      <div className="flex-1 space-y-6">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white">
            Explorar Eventos
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Encuentra y reserva tus entradas para los eventos más esperados de 2026.
          </p>
        </div>

        {/* Live Search and Filters Bar */}
        <SearchBar
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          selectedCategory={activeCategory}
          onCategoryChange={(cat) => setCategoryFilter(cat)}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />

        {/* Events Grid */}
        {filteredEvents.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-4">
            <span className="text-4xl">🔎</span>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
              No se encontraron eventos
            </h3>
            <p className="text-sm text-gray-500 max-w-md mx-auto">
              Intenta cambiar los términos de búsqueda o seleccionar otra categoría.
            </p>
            <button
              onClick={() => {
                setSearchTerm("");
                setCategoryFilter("all");
                setSortBy("default");
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-500 transition-colors"
            >
              Restablecer filtros
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function EventsPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center">Cargando catálogo...</div>}>
      <EventsContent />
    </Suspense>
  );
}
