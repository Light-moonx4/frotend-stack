import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eventsData } from "@/data/events";
import FavoriteButton from "@/components/ui/FavoriteButton";
import EventCard from "@/components/ui/EventCard";

interface EventDetailPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: EventDetailPageProps): Promise<Metadata> {
  const { id } = await params;
  const event = eventsData.find((item) => item.id === id);

  if (!event) {
    return {
      title: "Evento No Encontrado - Shadow Catálogo",
    };
  }

  return {
    title: `${event.title} | Shadow Catálogo`,
    description: event.description,
    openGraph: {
      title: event.title,
      description: event.description,
      images: [{ url: event.imageUrl }],
    },
  };
}

export default async function EventDetailPage({ params }: EventDetailPageProps) {
  const { id } = await params;
  const event = eventsData.find((item) => item.id === id);

  if (!event) {
    notFound();
  }

  const relatedEvents = eventsData
    .filter((item) => item.category === event.category && item.id !== event.id)
    .slice(0, 3);

  return (
    <div className="mx-auto max-w-5xl px-6 py-8 space-y-12">
      {/* Back Button */}
      <Link
        href="/events"
        className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-500 dark:text-blue-400 transition-colors"
      >
        &larr; Volver a Todos los Eventos
      </Link>

      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-xl">
        <div className="relative h-72 sm:h-96 w-full">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

          <div className="absolute top-4 right-4">
            <FavoriteButton eventId={event.id} />
          </div>

          <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-600 text-white">
              {event.category}
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
              {event.title}
            </h1>
            <p className="text-sm sm:text-base text-gray-200 flex items-center gap-2">
              📍 {event.location} &bull; 📅 {event.date}
            </p>
          </div>
        </div>

        {/* Info Grid */}
        <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-8 border-t border-gray-100 dark:border-gray-800">
          <div className="md:col-span-2 space-y-6">
            <div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Acerca de este evento
              </h3>
              <p className="mt-3 text-gray-600 dark:text-gray-300 leading-relaxed text-base">
                {event.description}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/60 space-y-2 text-sm text-gray-700 dark:text-gray-300">
              <p><strong>Organizado por:</strong> {event.organizer}</p>
              <p><strong>Aforo máximo:</strong> {event.capacity.toLocaleString()} personas</p>
            </div>
          </div>

          {/* Ticket Booking Card */}
          <div className="p-6 rounded-2xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/40 space-y-6 self-start shadow-sm">
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Precio de entrada</p>
              <p className="text-3xl font-extrabold text-blue-600 dark:text-blue-400 mt-1">
                {event.price === 0 ? "¡Gratis!" : `$${event.price} USD`}
              </p>
            </div>

            <div className="space-y-2 text-xs text-gray-600 dark:text-gray-400 border-t border-b border-gray-200 dark:border-gray-700 py-3">
              <p className="flex justify-between">
                <span>Disponibles:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{event.availableTickets} tickets</span>
              </p>
              <p className="flex justify-between">
                <span>Estado:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">Venta abierta</span>
              </p>
            </div>

            <Link
              href={`/events?buy=${event.id}`}
              className="block w-full py-3 text-center rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-md shadow-blue-500/20 transition-all"
            >
              Comprar / Reservar Entradas
            </Link>
          </div>
        </div>
      </div>

      {/* Related Events */}
      {relatedEvents.length > 0 && (
        <div className="space-y-6 pt-6 border-t border-gray-200 dark:border-gray-800">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Eventos Relacionados
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedEvents.map((item) => (
              <EventCard key={item.id} event={item} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
