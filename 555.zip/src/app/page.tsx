import Link from "next/link";
import { eventsData } from "@/data/events";
import { categoriesData } from "@/data/categories";
import EventCard from "@/components/ui/EventCard";

export default function Home() {
  const featuredEvents = eventsData.filter((e) => e.featured);
  const mainCategories = categoriesData.filter((c) => c.slug !== "all");

  return (
    <div className="flex flex-col gap-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 via-zinc-50 to-transparent dark:from-blue-950/30 dark:via-black dark:to-transparent py-20 px-6">
        <div className="mx-auto max-w-5xl text-center space-y-6">
          <span className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-900">
            ✨ Plataforma #1 en Eventos y Entretenimiento
          </span>
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-gray-900 dark:text-white leading-tight">
            Descubre y vive los mejores{" "}
            <span className="bg-gradient-to-r from-blue-600 to-indigo-500 bg-clip-text text-transparent">
              Eventos y Experiencias
            </span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
            Explora conciertos masivos, torneos de videojuegos, muestras de teatro e históricas finales de fútbol. Reserva tus entradas en segundos.
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <Link
              href="/events"
              className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition-all hover:scale-105"
            >
              Explorar Eventos &rarr;
            </Link>
            <Link
              href="/categories"
              className="px-6 py-3.5 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-gray-900 dark:text-white font-bold text-sm hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
            >
              Ver Categorías
            </Link>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="mx-auto max-w-4xl mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 p-6 rounded-2xl bg-white/70 dark:bg-gray-900/70 backdrop-blur-md border border-gray-200 dark:border-gray-800 shadow-sm text-center">
          <div>
            <p className="text-3xl font-extrabold text-blue-600 dark:text-blue-400">10+</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Eventos Exclusivos</p>
          </div>
          <div>
            <p className="text-3xl font-extrabold text-purple-600 dark:text-purple-400">4</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Categorías Principales</p>
          </div>
          <div>
            <p className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">500K+</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Asistentes Esperados</p>
          </div>
          <div>
            <p className="text-3xl font-extrabold text-amber-600 dark:text-amber-400">100%</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Reservas Garantizadas</p>
          </div>
        </div>
      </section>

      {/* Featured Events Section */}
      <section className="mx-auto max-w-7xl px-6 w-full space-y-8">
        <div className="flex items-end justify-between border-b border-gray-200 dark:border-gray-800 pb-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Imprescindibles
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mt-1">
              ⭐ Eventos Destacados
            </h2>
          </div>
          <Link
            href="/events"
            className="text-sm font-semibold text-blue-600 hover:text-blue-500 dark:text-blue-400 transition-colors"
          >
            Ver todos ({eventsData.length}) &rarr;
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </section>

      {/* Categories Grid Section */}
      <section className="mx-auto max-w-7xl px-6 w-full space-y-8">
        <div className="flex items-end justify-between border-b border-gray-200 dark:border-gray-800 pb-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Variedad
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mt-1">
              📂 Categorías Populares
            </h2>
          </div>
          <Link
            href="/categories"
            className="text-sm font-semibold text-blue-600 hover:text-blue-500 dark:text-blue-400 transition-colors"
          >
            Todas las categorías &rarr;
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {mainCategories.map((cat) => {
            const count = eventsData.filter((e) => e.category === cat.slug).length;
            return (
              <Link
                key={cat.id}
                href={`/events?category=${cat.slug}`}
                className="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className="relative z-10 flex flex-col h-full justify-between space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-4xl">{cat.icon}</span>
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300">
                      {count} evento(s)
                    </span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-blue-500 transition-colors">
                      {cat.name}
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                      {cat.description}
                    </p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="mx-auto max-w-7xl px-6 w-full">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-700 p-8 sm:p-12 text-white shadow-2xl">
          <div className="relative z-10 max-w-2xl space-y-4">
            <h2 className="text-3xl sm:text-4xl font-black">
              ¿Organizas un evento o quieres publicar uno nuevo?
            </h2>
            <p className="text-blue-100 text-sm sm:text-base leading-relaxed">
              Agrega tus propias categorías y eventos al catálogo en segundos a través del panel de administración.
            </p>
            <div className="pt-2">
              <Link
                href="/admin/categories/create"
                className="inline-block px-6 py-3.5 rounded-xl bg-white text-blue-600 font-bold text-sm shadow-md hover:bg-blue-50 transition-all"
              >
                Crear Categoría Ahora &rarr;
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
