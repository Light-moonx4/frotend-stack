"use client";

import { useState } from "react";
import Link from "next/link";

export default function CreateCategoryAdminPage() {
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("🏷️");
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !slug) return;

    setSuccess(true);
    setTimeout(() => {
      setName("");
      setSlug("");
      setDescription("");
      setIcon("🏷️");
      setSuccess(false);
    }, 3000);
  };

  const handleNameChange = (val: string) => {
    setName(val);
    // Auto generate slug
    setSlug(
      val
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9 -]/g, "")
        .replace(/\s+/g, "-")
    );
  };

  return (
    <div className="mx-auto max-w-2xl p-6 space-y-8">
      <div>
        <Link href="/categories" className="text-xs font-semibold text-blue-500 hover:underline">
          &larr; Volver a Categorías
        </Link>
        <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white mt-2">
          ➕ Crear Nueva Categoría
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Panel de Administración - Agrega nuevas categorías para clasificar los eventos del catálogo.
        </p>
      </div>

      {success && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-sm font-semibold flex items-center gap-2">
          ✓ Categoría &quot;{name || slug}&quot; creada exitosamente (simulado).
        </div>
      )}

      <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-6">
        <div>
          <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
            Nombre de la Categoría
          </label>
          <input
            type="text"
            required
            placeholder="Ej: Cine & Audiovisual"
            value={name}
            onChange={(e) => handleNameChange(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
            Slug de URL (generado automáticamente)
          </label>
          <input
            type="text"
            required
            placeholder="ej: cine-audiovisual"
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              Emoji / Icono
            </label>
            <input
              type="text"
              required
              value={icon}
              onChange={(e) => setIcon(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-sm text-center"
            />
          </div>

          <div className="sm:col-span-3">
            <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
              Descripción Corta
            </label>
            <input
              type="text"
              placeholder="Ej: Proyecciones, festivales de cine y cortometrajes."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-3">
          <Link
            href="/categories"
            className="px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-800 text-xs font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            Cancelar
          </Link>
          <button
            type="submit"
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 transition-colors"
          >
            Guardar Categoría
          </button>
        </div>
      </form>
    </div>
  );
}

