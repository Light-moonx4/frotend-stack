import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { categoriesData } from "@/data/categories";
import { eventsData } from "@/data/events";
import EventCard from "@/components/ui/EventCard";

interface CategoryDetailPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: CategoryDetailPageProps): Promise<Metadata> {
  const { slug } = await params;
  const category = categoriesData.find((item) => item.slug === slug);

  if (!category) {
    return { title: "Categoría No Encontrada - Shadow Catálogo" };
  }

  return {
    title: `${category.name} | Eventos - Shadow Catálogo`,
    description: category.description,
  };
}

export default async function CategoryDetailPage({ params }: CategoryDetailPageProps) {
  const { slug } = await params;
  const category = categoriesData.find((item) => item.slug === slug);

  if (!category && slug !== "all") {
    notFound();
  }

  const events = slug === "all" ? eventsData : eventsData.filter((event) => event.category === slug);

  return (
    <div className="mx-auto max-w-6xl p-6 space-y-8">
      {/* Category Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-700 p-8 text-white shadow-xl">
        <div className="relative z-10 space-y-3">
          <span className="text-4xl">{category?.icon ?? "📂"}</span>
          <h1 className="text-3xl sm:text-4xl font-extrabold capitalize">
            {category?.name ?? slug}
          </h1>
          <p className="text-blue-100 max-w-2xl text-sm leading-relaxed">
            {category?.description ?? "Explora los eventos asignados a esta categoría."}
          </p>
          <div className="pt-2 text-xs font-semibold text-blue-200">
            {events.length} evento(s) disponible(s)
          </div>
        </div>
      </div>

      {/* Events Grid */}
      {events.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-4">
          <p className="text-gray-600 dark:text-gray-400">
            No hay eventos registrados en esta categoría en este momento.
          </p>
          <Link href="/events" className="inline-block text-blue-500 hover:underline text-sm font-semibold">
            &larr; Ver todos los eventos
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}

      {/* Footer Navigation */}
      <div className="pt-6 border-t border-gray-200 dark:border-gray-800 flex gap-4">
        <Link href="/categories" className="text-sm font-semibold text-blue-500 hover:underline">
          &larr; Volver a Categorías
        </Link>
        <Link href="/events" className="text-sm font-semibold text-blue-500 hover:underline">
          Ver Catálogo Completo &rarr;
        </Link>
      </div>
    </div>
  );
}
