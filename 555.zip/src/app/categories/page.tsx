import Link from "next/link";
import { categoriesData } from "@/data/categories";
import { eventsData } from "@/data/events";
import CategoriesAside from "@/components/categories/CategoriesAside";
import CreateCategoriesButton from "@/components/ui/CreateCategoriesButton";

export const metadata = {
  title: "Categorías de Eventos - Shadow Catálogo",
  description: "Explora eventos clasificados por categorías: Música, Videojuegos, Teatro, Fútbol y más.",
};

export default function CategoriesPage() {
  return (
    <div className="mx-auto max-w-7xl p-6 flex flex-col md:flex-row gap-8">
      {/* Sidebar Categories */}
      <CategoriesAside />

      {/* Main Content */}
      <div className="flex-1 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 dark:border-gray-800 pb-6">
          <div>
            <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white">
              📂 Categorías
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Selecciona una categoría para explorar todos los eventos asociados.
            </p>
          </div>
          <CreateCategoriesButton />
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categoriesData.map((cat) => {
            const eventsCount =
              cat.slug === "all"
                ? eventsData.length
                : eventsData.filter((e) => e.category === cat.slug).length;

            return (
              <div
                key={cat.id}
                className="group relative overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
              >
                {/* Image & Overlay */}
                <div className="relative h-40 w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                  <div className="absolute top-4 left-4 text-3xl">{cat.icon}</div>
                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-white">
                    <h3 className="text-xl font-bold">{cat.name}</h3>
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 backdrop-blur-md">
                      {eventsCount} evento(s)
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
                    {cat.description}
                  </p>
                  <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                    <Link
                      href={cat.slug === "all" ? "/events" : `/categories/${cat.slug}`}
                      className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Ver Categoría &rarr;
                    </Link>
                    <Link
                      href={cat.slug === "all" ? "/events" : `/events?category=${cat.slug}`}
                      className="px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-800 text-xs font-semibold text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                    >
                      Filtrar Eventos
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}