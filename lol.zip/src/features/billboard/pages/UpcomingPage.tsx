import React, { useEffect, useState, useMemo } from 'react';
import type { UpcomingMovie } from '../interfaces/upcoming.interface';
import { getUpcomingMovies, subscribeToUpcomingNotification } from '../services/upcomingServices';
import { CountdownTimer } from '../components/CountdownTimer';
import { UpcomingDetailModal } from '../components/UpcomingDetailModal';

export const UpcomingPage: React.FC = () => {
  const [movies, setMovies] = useState<UpcomingMovie[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedGenre, setSelectedGenre] = useState<string>('ALL');
  const [selectedMovie, setSelectedMovie] = useState<UpcomingMovie | null>(null);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);

  // Simulación temporal de estado de autenticación (conectar con tu store global)
  const [isAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    getUpcomingMovies()
      .then((data) => {
        // Ordenar las películas por fecha de estreno de forma ascendente
        const sorted = data.sort(
          (a, b) => new Date(a.releaseDate).getTime() - new Date(b.releaseDate).getTime()
        );
        setMovies(sorted);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const genres = useMemo(() => {
    const set = new Set<string>();
    movies.forEach((m) => m.genres?.forEach((g) => set.add(g)));
    return Array.from(set);
  }, [movies]);

  const filteredMovies = useMemo(() => {
    if (selectedGenre === 'ALL') return movies;
    return movies.filter((m) => m.genres?.includes(selectedGenre));
  }, [movies, selectedGenre]);

  const handleNotify = async (movieId: string) => {
    try {
      await subscribeToUpcomingNotification(movieId);
      setMovies((prev) =>
        prev.map((m) => (m.id === movieId ? { ...m, isNotified: true } : m))
      );
      if (selectedMovie?.id === movieId) {
        setSelectedMovie((prev) => (prev ? { ...prev, isNotified: true } : null));
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-white">Cargando próximos estrenos...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-white">Próximos Estrenos</h1>
        <select
          value={selectedGenre}
          onChange={(e) => setSelectedGenre(e.target.value)}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg border border-slate-700"
        >
          <option value="ALL">Todos los géneros</option>
          {genres.map((genre) => (
            <option key={genre} value={genre}>
              {genre}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredMovies.map((movie) => (
          <div
            key={movie.id}
            className="bg-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
          >
            <img
              src={movie.posterUrl}
              alt={movie.title}
              className="w-full h-80 object-cover cursor-pointer"
              onClick={() => setSelectedMovie(movie)}
            />
            <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg text-white line-clamp-1">{movie.title}</h3>
                <p className="text-xs text-gray-400 mt-1">
                  {new Date(movie.releaseDate).toLocaleDateString()}
                </p>
              </div>
              <CountdownTimer targetDate={movie.releaseDate} />
              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setSelectedMovie(movie)}
                  className="flex-1 text-xs py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg"
                >
                  Ver detalle
                </button>
                <button
                  disabled={movie.isNotified}
                  onClick={() =>
                    isAuthenticated ? handleNotify(movie.id) : setShowAuthModal(true)
                  }
                  className={`flex-1 text-xs py-2 rounded-lg font-semibold transition ${
                    movie.isNotified
                      ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {movie.isNotified ? 'Notificado' : 'Notificarme'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <UpcomingDetailModal
        movie={selectedMovie}
        onClose={() => setSelectedMovie(null)}
        onNotify={handleNotify}
        isAuthenticated={isAuthenticated}
        onOpenAuth={() => setShowAuthModal(true)}
      />

      {showAuthModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-800 p-6 rounded-xl max-w-sm w-full text-center space-y-4">
            <h3 className="text-xl font-bold text-white">Inicio de sesión requerido</h3>
            <p className="text-sm text-gray-300">
              Debes iniciar sesión para suscribirte a las notificaciones de este estreno.
            </p>
            <div className="flex gap-2 justify-center">
              <button
                onClick={() => setShowAuthModal(false)}
                className="px-4 py-2 bg-slate-700 text-white rounded-lg text-sm"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};